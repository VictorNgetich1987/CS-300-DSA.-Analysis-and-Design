//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : [Your Name]
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Lab 5-2 Binary Search Tree � Fully Fixed & Tested
//============================================================================

#include <iostream>
#include <time.h>
#include <functional>   // For std::function
#include <string>       // For std::string, stod
#include <stdexcept>    // For exception handling
#include <algorithm>    // For std::remove
#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions
//============================================================================

// Forward declaration
double strToDouble(string str, char ch);

// Define Bid
struct Bid {
    string bidId;
    string title;
    string fund;
    double amount;
    Bid() : amount(0.0) {}
};

// Define Node
struct Node {
    Bid bid;
    Node *left;
    Node *right;

    Node() : left(nullptr), right(nullptr) {}
    Node(Bid aBid) : bid(aBid), left(nullptr), right(nullptr) {}
};

// --- Define displayBid BEFORE BinarySearchTree ---
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
         << bid.fund << endl;
}

//============================================================================
// Binary Search Tree class
//============================================================================

class BinarySearchTree {
private:
    Node* root;

    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    void postOrder(Node* node);
    void preOrder(Node* node);
    Node* removeNode(Node* node, string bidId);
    Node* findMin(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void PostOrder();
    void PreOrder();
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
};

BinarySearchTree::BinarySearchTree() {
    root = nullptr;
}

BinarySearchTree::~BinarySearchTree() {
    function<void(Node*)> deleteNodes = [&](Node* node) {
        if (node != nullptr) {
            deleteNodes(node->left);
            deleteNodes(node->right);
            delete node;
        }
    };
    deleteNodes(root);
}

void BinarySearchTree::InOrder() { inOrder(root); }
void BinarySearchTree::PostOrder() { postOrder(root); }
void BinarySearchTree::PreOrder() { preOrder(root); }

void BinarySearchTree::Insert(Bid bid) {
    if (root == nullptr) {
        root = new Node(bid);
    } else {
        addNode(root, bid);
    }
}

void BinarySearchTree::Remove(string bidId) {
    root = removeNode(root, bidId);
}

Bid BinarySearchTree::Search(string bidId) {
    Node* current = root;
    while (current != nullptr) {
        if (bidId == current->bid.bidId) {
            return current->bid;
        } else if (bidId < current->bid.bidId) {
            current = current->left;
        } else {
            current = current->right;
        }
    }
    return Bid();
}

Node* BinarySearchTree::findMin(Node* node) {
    if (node == nullptr) return nullptr;
    while (node->left != nullptr) {
        node = node->left;
    }
    return node;
}

void BinarySearchTree::addNode(Node* node, Bid bid) {
    if (bid.bidId < node->bid.bidId) {
        if (node->left == nullptr) {
            node->left = new Node(bid);
        } else {
            addNode(node->left, bid);
        }
    } else {
        if (node->right == nullptr) {
            node->right = new Node(bid);
        } else {
            addNode(node->right, bid);
        }
    }
}

void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) {
        inOrder(node->left);
        displayBid(node->bid);
        inOrder(node->right);
    }
}

void BinarySearchTree::postOrder(Node* node) {
    if (node != nullptr) {
        postOrder(node->left);
        postOrder(node->right);
        displayBid(node->bid);
    }
}

void BinarySearchTree::preOrder(Node* node) {
    if (node != nullptr) {
        displayBid(node->bid);
        preOrder(node->left);
        preOrder(node->right);
    }
}

Node* BinarySearchTree::removeNode(Node* node, string bidId) {
    if (node == nullptr) return nullptr;

    if (bidId < node->bid.bidId) {
        node->left = removeNode(node->left, bidId);
    } else if (bidId > node->bid.bidId) {
        node->right = removeNode(node->right, bidId);
    } else {
        // Node to delete
        if (!node->left && !node->right) {
            delete node;
            return nullptr;
        } else if (!node->left) {
            Node* temp = node->right;
            delete node;
            return temp;
        } else if (!node->right) {
            Node* temp = node->left;
            delete node;
            return temp;
        } else {
            Node* temp = findMin(node->right);
            node->bid = temp->bid;
            node->right = removeNode(node->right, temp->bid.bidId);
        }
    }
    return node;
}

//============================================================================
// Helper Functions
//============================================================================

/**
 * Safely convert string (e.g., "$71.88") to double
 */
double strToDouble(string str, char ch) {
    if (str.empty()) return 0.0;

    // Remove all occurrences of 'ch' (e.g., '$')
    str.erase(remove(str.begin(), str.end(), ch), str.end());

    // Trim whitespace
    size_t start = str.find_first_not_of(" \t\n\r");
    size_t end = str.find_last_not_of(" \t\n\r");
    if (start == string::npos) return 0.0;
    str = str.substr(start, end - start + 1);

    // Convert
    try {
        return stod(str);
    } catch (...) {
        return 0.0;
    }
}

/**
 * Load bids from CSV
 */
void loadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    try {
        csv::Parser file = csv::Parser(csvPath);

        // Print header
        vector<string> header = file.getHeader();
        for (size_t i = 0; i < header.size(); ++i) {
            cout << header[i];
            if (i < header.size() - 1) cout << " | ";
        }
        cout << endl;

        for (unsigned int i = 0; i < file.rowCount(); ++i) {
            Bid bid;
            bid.bidId = file[i][1];      // Bid ID
            bid.title = file[i][0];      // Title
            bid.fund = file[i][8];       // Fund

            // Safely extract and convert amount (column 4)
            string amountRaw = file[i][4];
            bid.amount = strToDouble(amountRaw, '$');

            bst->Insert(bid);
        }

        cout << file.rowCount() << " bids read" << endl;

    } catch (csv::Error &e) {
        cerr << "CSV Error: " << e.what() << endl;
    } catch (exception &e) {
        cerr << "Error: " << e.what() << endl;
    }
}

//============================================================================
// Main
//============================================================================

int main(int argc, char* argv[]) {
    string csvPath, bidKey;
    switch (argc) {
        case 2:
            csvPath = argv[1];
            bidKey = "98223";
            break;
        case 3:
            csvPath = argv[1];
            bidKey = argv[2];
            break;
        default:
            csvPath = "eBid_Monthly_Sales.csv";
            bidKey = "98223";
    }

    clock_t ticks;
    BinarySearchTree* bst = new BinarySearchTree();
    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "\nMenu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                ticks = clock();
                loadBids(csvPath, bst);
                ticks = clock() - ticks;
                cout << "time: " << ticks << " clock ticks" << endl;
                cout << "time: " << static_cast<double>(ticks) / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 2:
                cout << "\n=== All Bids (In-Order) ===" << endl;
                bst->InOrder();
                break;

            case 3:
                cout << "\nSearching for bid: " << bidKey << endl;
                ticks = clock();
                bid = bst->Search(bidKey);
                ticks = clock() - ticks;

                if (!bid.bidId.empty()) {
                    displayBid(bid);
                } else {
                    cout << "Bid Id " << bidKey << " not found." << endl;
                }
                cout << "time: " << ticks << " clock ticks" << endl;
                cout << "time: " << static_cast<double>(ticks) / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 4:
                cout << "\nRemoving bid: " << bidKey << endl;
                bst->Remove(bidKey);
                cout << "Bid " << bidKey << " removed (if it existed)." << endl;
                break;

            case 9:
                cout << "Good bye." << endl;
                break;

            default:
                cout << "Invalid choice. Try again." << endl;
        }
    }

    delete bst;
    return 0;
}
